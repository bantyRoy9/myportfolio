const express = require('express');
const mongoose = require('mongoose');
const dotenve = require('dotenv');
const errorHandler = require('./middlewares/errorHandler')
const port = process.env.PORT || 5000;

const app = express(); 
dotenve.config({path: './config.env'});
app.use(express.json());
app.use(require('./router/index'));
require('./DataBase/db');



app.use(errorHandler);
app.listen(port,()=>{
    console.log(`server run at port ${port}`);
});