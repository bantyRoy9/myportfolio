const express = require('express')

const router = express.Router();

const registercontroller = require('../controller/auth/registercontroller');
const Logincontroller = require('../controller/auth/Logincontroller');
const usercontroller = require('../controller/auth/usercontroller');
const auth = require('../middlewares/auth');

router.post('/register',registercontroller.register);
router.post('/Login',Logincontroller.Login);
router.get('/me',auth, usercontroller.me);

module.exports = router;