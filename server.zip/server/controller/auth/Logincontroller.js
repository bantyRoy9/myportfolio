const joi = require('joi');
const User = require('../../modals/user');
const CustomErrorHandler = require('../../services/CustomErrorHandler');
const JwtService = require('../../services/JwtService');
const bcrypt = require('bcrypt');


const Logincontroller = {
    async Login(req,res,next){
        const loginSchema = joi.object( {
                email: joi.string().email().required(),
                password: joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required()

        });

        const {error} = loginSchema.validate(req.body);
        if(error){
            return next(error);
        }

        try{
            const user = await User.findOne({email: req.body.email});
                if(!user){
                    return next(CustomErrorHandler.wrongCredentials());
                }


                const match = await bcrypt.compare(req.body.password,user.password)
                if(!match){
                    return next(CustomErrorHandler.wrongCredentials());     
                }

                const access_token = JwtService.sign({_id:user._id, role:user.role});
                res.json({access_token});
        }catch(err){
            return next(err);
        }

    }
};
module.exports = Logincontroller;