const CustomErrorHandler = require('../../services/CustomErrorHandler');
const JwtService = require('../../services/JwtService');
const User=require('../../modals/user');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const joi = require('joi');
require('../../DataBase/db');
const registercontroller = {

      async register(req,res,next) {

        //validatation
        const registerSchema = joi.object({

            name: joi.string().min(3).max(15).required(),
            email: joi.string().email().required(),
            phone: joi.string().regex(/^[0-9]{10}$/).messages({'string.pattern.base': `Phone number must have 10 digits.`}).required(),
            password: joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required(),
            cpassword: joi.ref('password')
        })
         const {error} = registerSchema.validate(req.body);
            if(error){
                return next(error);
            }

        // check if user is in the database already
        try{
            const exist = await User.exists({email:req.body.email});
            if(exist){
                // return res.json({msg:"not ok"});
                return next(CustomErrorHandler.alreadyExist('this is already exixts'));
            }

        }catch(err){
        //   res.json({msg:"not skfskgok"});
            return next(err);
        }

        // password hash

       const {name,email,phone,password}=req.body;
        const hashPassword = await bcrypt.hash(password,10);

        // prepare the model
        const user = new User( {
            name,
            email,
            phone,
            password: hashPassword
        });


        let access_token;

        try{
            const result = await user.save();
            console.log(result);

            access_token = JwtService.sign({_id:result._id, role:result.role})

        }catch(err){
            return next(err);
        }
        


          res.json({access_token: access_token});
        //   res.json({msg:"ok"});?
        }
}
module.exports = registercontroller;